#!/bin/bash
#
# provides some help on status of git submodules when developing
#
#  Requires more up-to-date version of git:
#   lsetup git
#  
# This routine will generally be called when submodules are on master branch i.e. after
#   setup_submodule_branches.sh 
# has been called
#  
# To go back to the original submodule hashtags do 
#   git submodule update
#
if [ "$1" = "-h" ] || [ "$1" = "--help" ] ; then
    echo 
    echo "git submodule helper script. Prerequisites: ATLAS software setup: setupATLAS and lsetup git "
    echo 
    echo "Usage: $0 [option...]" 
    echo
    echo "   no option (default)        print out useful information"
    echo "   -w, --write                write a gitlab markdown list of the package diff urls - useful for merge request Overview tab"
    echo "   -h, --help                 this help " 
    echo
    kill -INT $$
fi

echo -e "Looking for new hashtags in submodules:\n"
diff_out=`git diff --submodule | grep Submodule | grep "\.\."`
#echo "$diff_out"

fileout=gitlab.md

writefile=false
if [ "$1" = "-w" ] || [ "$1" = "--write" ] ; then
    echo -e "Writing gitlab package diff urls to $fileout\n" 
    if [ -f $fileout ]; then
	echo -e "  moving existing file to ${fileout}_orig\n"
	mv ${fileout} ${fileout}_orig
    fi
    writefile=true
    echo -e "The following changes were made:\n" > $fileout
fi
 
# test for matching submodule to url (requires #lsetup git)
#modules=`git show HEAD:.gitmodules | git config --file - --list | grep url`
# for vhresonance
#modules=`git config --file .git/config --list | grep url`
#echo "modules $modules"

while read -r line 
do 
    #echo "line:" $line
    if [[ -z $line ]]; then
	echo "git diff --submodules found no differences"
        break
    fi
    # get the package and hashtags from git diff --submodule command
    pkg=`echo $line | awk -F' ' '{print $2}'`
    hashtag=`echo $line | awk -F' ' '{print $3}'`    
    hashtag=`echo $hashtag | sed s/://`
    # old hashtag
    hashtag_old=`echo $hashtag | awk -F'.' '{print $1}'`
    # may have .. or ... separating hashtags
    ndots=`echo $hashtag | awk -F"." '{print NF-1}'`
    #echo "ndots" $ndots
    if (( $ndots == 3 )) ; then 
	hashtag_new=`echo $hashtag | awk -F'.' '{print $4}'`
    else
	hashtag_new=`echo $hashtag | awk -F'.' '{print $3}'`
    fi
    echo "Found new commits to package: $pkg from $hashtag_old to $hashtag_new"
    echo " for more details use either of these commands:"
    echo "  cd $pkg; git diff $hashtag_old $hashtag_new; cd -"
    # have a go at matching name to url
    module_url=`git show HEAD:.gitmodules | git config --file /dev/stdin --list | grep "submodule.$pkg.url"` 
    # vhresonance
    #module_url=`git config --file .git/config --list | grep "submodule.$pkg.url"` 
    module_url=`echo $module_url | awk -F= '{print $2}'`
    module_url=`echo $module_url | sed s/'\.git'//`
    module_url=`echo $module_url | awk -F/ '{ for (x=4; x<=NF; x++) printf("%s/", $x);printf("\n")}'`
    #echo "module $module_url"    
    echo "  gio open 'https://gitlab.cern.ch/${module_url}compare/$hashtag_old...$hashtag_new' &"
    echo "WARNING: gitlab compare url may say 'nothing to compare' due to \
git diff $hashtag_old...$hashtag_new versus git diff $hashtag_old..$hashtag_new"
    echo ""
    if [ "$writefile" = true ]; then
	echo -e "$pkg:" >> $fileout
	echo "https://gitlab.cern.ch/${module_url}compare/$hashtag_old...$hashtag_new" >> $fileout
	echo -e "\n" >> $fileout
    fi
done <<< "$diff_out"

# 
echo ""
echo "Note: some notes on these useful submodule commands:"
echo "git diff --submodule # equivalent to 'git diff submodule=log'"  
echo "git diff --submodule=short # slightly longer format"  
echo "git diff --submodule=diff # in-line diff - requires 'lsetup git' first"
echo "git submodule status # for more expert overview"  

