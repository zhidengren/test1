#!/bin/bash
# This script extracts the latest INSTALL instructions directly from the README
# Commands that are marked with #install_script in README.md will be extracted to the
# INSTALL script and then executed

# first save the old working directory 
PREVIOUS_DIR=${OLDPWD}
# store directory that the script is running in:
SOURCE_DIR=$(cd "$(dirname ${BASH_SOURCE[0]})" && pwd)

package=$(basename $SOURCE_DIR)
#
# script greps inside CMakeList.txt to find AnalysisBase version - make sure
# you have checked out the correct version of $package and submodule update etc..
#
export ATLAS_LOCAL_ROOT_BASE=/cvmfs/atlas.cern.ch/repo/ATLASLocalRootBase
alias setupATLAS='source ${ATLAS_LOCAL_ROOT_BASE}/user/atlasLocalSetup.sh'

AB=`grep 'EXACT REQUIRED' CMakeLists.txt | awk -F' ' '{print $3}'`
XXX=`echo $AB | awk -F'.' '{print $3}'`
echo ""
echo "Installing $package"
echo "--------------------------"
echo -e "with AnalysisBase $AB\n"
echo "Parsing README.md file to create install script..."
grep "#install_script" "README.md" | sed 's/#install_script//g'  > INSTALL
sed -i "s/XXX/$AB/" INSTALL
# to get rid of all comments
#sed -i 's/#.*$//g' INSTALL  
echo "Done! Created install script here: ${PWD}/INSTALL"
echo "----"
cat INSTALL
echo "----"
echo "source INSTALL"
echo "Installing..."
source INSTALL
echo "back to $package directory $SOURCE_DIR"
cd $SOURCE_DIR
echo "Cleaning up..."
rm -f INSTALL
#
OLDPWD=${PREVIOUS_DIR}
