#!/bin/bash
#
# This script can be used to set up all of the submodules of the repository
# to point to the HEAD of a particular branch. Which is useful when:
#  - updating the repository to include changes made by other people in the
#    submodule repositories;
#  - setting up a new clone of this repository for developments on the
#    submodules.
#

# Stop on errors:
#set -e

# save the old working directory 
PREVIOUS_DIR=${OLDPWD}
# The directory that the script is running in:
SOURCE_DIR=$(cd "$(dirname ${BASH_SOURCE[0]})" && pwd)


# Helper function
function checkout_branch() {
    # Grab the function's arguments:
    SUBMODULE_DIR=$1
    SUBMODULE_BRANCH=$2
    # Check out the requested branch for the specified submodule:
    cd ${SOURCE_DIR}/${SUBMODULE_DIR}/
    echo "$SUBMODULE_DIR"
    userbranch=${SUBMODULE_BRANCH}-${USER}
    
    # first check if user branch exists
    exists_userbranch=$(git branch --list ${userbranch})
    
    if [[ -z ${exists_userbranch} ]]; then
	# does not exist so we create
	git checkout ${SUBMODULE_BRANCH} -b ${userbranch}
    else
	# exists so just checkout
	git checkout ${userbranch}
    fi
    #
    git fetch
    git merge ${SUBMODULE_BRANCH}
}

# Go to the HEAD of all the submodules:
tag_or_branch=origin/master
# following used to make r32-24 CxAODReaderCore tags
#tag_or_branch=r32-24-Reader-Resolved-05-CSFix
#tag_or_branch=r32-24-Reader-boosted-06
#Core
checkout_branch Core/CxAODReader      $tag_or_branch
checkout_branch Core/CxAODTools       $tag_or_branch
checkout_branch Core/CxAODOperations  $tag_or_branch 

# VHbb
checkout_branch VHbb/CxAODReader_VHbb      $tag_or_branch  
checkout_branch VHbb/CxAODOperations_VHbb  $tag_or_branch 
checkout_branch VHbb/CxAODTools_VHbb       $tag_or_branch
checkout_branch VHbb/CorrsAndSysts         $tag_or_branch
checkout_branch VHbb/KinematicFit          $tag_or_branch
    
cd ${SOURCE_DIR}
OLDPWD=${PREVIOUS_DIR}
