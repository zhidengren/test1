# ***This project is part of the [CxAODFramework](https://gitlab.cern.ch/CxAODFramework) the [wiki](https://gitlab.cern.ch/CxAODFramework/CxAODOperations_VHbb/wikis/home) contains detailed documentation.***

# Hadd files   
There is a huge slow down of the `hadd` command for ROOT versions between v6.22.08 and 6.26.00 included (some are now patch corrected) due to a bug in ROOT, more details here [link issue](https://github.com/root-project/root/issues/9939).  
Anyway, the default version of ROOT on `lxplus` is affected by the bug.   
So if you do the hadd of the `hadded_all.root` files `a+d+e` that contain systematic histograms, please source a non affected version: 
```
source /cvmfs/sft.cern.ch/lcg/app/releases/ROOT/6.22.06/x86_64-centos7-gcc48-opt/bin/thisroot.sh
```
Then you are good to go for the hadd as usual.   
**The gain in time is huge: less than one hour vs one day without or with the bug!**

To do the hadd of `a+d+e` period please always use the following command: 
```
hadd hadded_all_0L_13TeV.root Reader_0L_33-24_[a,d,e]_Resolved_T_T/haddedHist/hadded_all.root
```
It avoids to have mistakes such as hadding `a+d+d` instead of `a+d+e`. 

The `[a,d,e]` is a regular expression the hadd understands it should hadd the 3 files:  
* `Reader_0L_33-24_a_Resolved_T_T/haddedHist/hadded_all.root`
* `Reader_0L_33-24_d_Resolved_T_T/haddedHist/hadded_all.root`
* `Reader_0L_33-24_e_Resolved_T_T/haddedHist/hadded_all.root`     

And similarly for trees 
```
hadd hadded_all_tree_0L_13TeV.root Reader_0L_33-24_[a,d,e]_Resolved_T_T/haddedTree/hadded_all.root
```

# CxAODReaderCore
Core package for VHbb CxAODReader, adds other packages as submodules
===================================================================

Based on Attilla's suggestions
https://gitlab.cern.ch/akraszna/CxAODBasedAnalysisExample

Getting The Code
----------------
In case you are cloning the repository not from `lxplus` you might need to do some setups with `GitLab` to get authorisations. Otherwise you will observe the error `Acces denied` when cloning the repository. 
Please refers to the corresponding [gitlab section](#gitlab-setup) below.

The work model is 
```
cd yourpath
git clone --recursive ssh://git@gitlab.cern.ch:7999/CxAODFramework/CxAODReaderCore.git
cd CxAODReaderCore
```
Note: CxAODReaderCore is the code "source" directory (the full path of the directory is referred to as \<source dir\> here). 
By default it downloads the latest tagged version of the code. 

If you already have the project cloned and forgot the "--recursive" argument you can do, from within
the cloned CxAODReaderCore directory, the following:
```
git submodule update --init --recursive
```
In this way you will dowload the latest tagged version of the code (not the master), which is recommended. 

If instead you want to run on the master you need to update the packages thanks to the following command: 
```
git submodule update --init --recursive --remote
```

Code Structure
--------------
This package is for the CxAODReader. The core CxAOD and VHbb specific CxAODReader packages are stored
in two separate subdirectories:

```
Core  VHbb
```
and the relevant packages are added as submodules to these directories.

Note: the submodules were added to the directories using commands such as;

```
git submodule add ssh://git@gitlab.cern.ch:7999/CxAODFramework/CxAODTools_VHbb.git VHbb/CxAODTools_VHbb
```

Building The Code
-----------------

The idea is that the setup is much simplified and the tags of this package will
determine the versions of the submodules and the AnalysisBase release.

The AnalysisBase release (XXX) is now stored in 
```
<source dir>/CMakeLists.txt
```
via the line
```
find_package( AnalysisBase XXX EXACT REQUIRED )
```
The EXACT REQUIRED ensures that you have the correct AnalysisBase version
setup when you do the cmake setup below.
Before beginning make sure that you have checked out the correct version of code and packages and that the
AnalysisBase version is set to what you expect. 

To build the code then instructions are given below. For convenience every line 
with the comment `install_script` in this README is parsed by the `install.sh` 
script so you can either do:
```
cd <source dir>
source ./install.sh
```
or follow the details and issue the commands below.

We need to first get the data that is only stored on afs rather than in the repository:

```
cd <source dir>
source ./copydatafromafs.sh                   #install_script
```

The repository behaves like any simple CMake based source repository. And you
can set up the appropriate analysis release and build it with e.g.:

```
mkdir ../build                                #install_script
cd ../build                                   #install_script
setupATLAS                    		      #install_script
lsetup git # get later version of git (required for utility check_submodules.sh)    #install_script
asetup AnalysisBase,XXX,here                                                        #install_script
cmake ../CxAODReaderCore							    #install_script
cmake --build .									    #install_script
source x*/setup.sh								    #install_script
```

and subsequent setups of the environment

```
cd yourpath
cd build
setupATLAS
lsetup git # get later version of git (required for utility check_submodules.sh)
asetup 
source x*/setup.sh
```

Getting Submodule Updates
-------------------------

When switching branches, updating to somebody else's developments, etc., you
need to execute the following command after whatever command you used to update
"this repository", to pull in the appropriate versions of all of the submodules:

```
git submodule update
```

See [the submodule documentation](https://git-scm.com/docs/git-submodule) for
further details.

Preparing The Code For Development
----------------------------------

When cloning the repository, all submodules will be in a "detached head" state.
Since submodules only remember which hash tag they are pointing at in a target
repository. They don't remember whether that hash tag belongs to any branch/tag.

To update all submodules to point to the HEAD of the appropriate branches in
their respective repositories, execute:

```
<source dir>/setup_submodule_branches.sh
```

But remember that this is only needed if you want to develop the code stored
in those repositories. Otherwise the recursive clone's setup will work just
fine out of the box.

Another script has been added to help with development
```
<source dir>/check_submodules.sh
```
this will remind you of the changes (after running setup_submodule_branches.sh)
from the last submodule hashtag to the master for all of the submodules (uses git diff --submodule).
Note, in order for it to provide the url to compare versions in a browser 
a more up-to-date version of git is required by doing lsetup git (see setup instructions). 

Tags
----

The tagging of the CxAOD code (and the submodule hash tags) is easily taken care of 
by tagging this package. Some more details at
```
<source dir>/createTag.sh
```

To switch to a particular tag then do e.g.
```
git checkout mytag -b mybranch
git submodule update
```
If you forget which tag your branch is associated to then do:
```
git describe --tags
```
You can check for any differences with that tag (you may have forgotten to update the submodules!) 
by doing 
```
git diff mytag
```
and look out for any differences in particular for the submodule hash tags (lines with +/-Subproject commit).

More easily one can see differences between 2 tags (here `r34-50` vs `r34-56`) using the following url (just change the tag to be compared):    
https://gitlab.cern.ch/CxAODFramework/CxAODReaderCore/-/compare/r34-50...r34-56. For the submodule changes one just need to click on the Compare buttons to see the different MRs added for the submodules 

r32-24-tags
-----------
The r32-24 reader tags (based on r32-15 CxAOD production) and used for the 2020 VHbb results are
(for resolved and boosted):\
r32-24-Reader-Resolved-05-CSFix\
r32-24-Reader-boosted-06

To switch to these versions do e.g.
```
git checkout r32-24-Reader-Resolved-05-CSFix
git submodule update
```

[comment]: <> (if you change the title of the section below please update the reference #gitlab-setup)
# GitLab setup 

In order to be able to download `GitLab` repositories from a server different than `lxplus` or on your own computer you will need first to generate a key pair to be added on `GitLab`. 

This setup **only needs to be done once** per server.   
(`e.g.` your lab server or a computing center server such as CC de Lyon's or on your computer). 


Below are the steps to follow (full details [here](https://gitlab.cern.ch/help/ssh/index.md)): 

* Connect via `ssh` to the server you want to download the repository. 
Or simply open a terminal if you want to download the repo on your computer) 

* Make sure the file `$HOME/.ssh/id_rsa.pub` does not exist. 
  ```bash
  cat $HOME/.ssh/id_rsa.pub
  ```
  If the command above does display a key you have already done the public/private key generation step. 

* To generate the needed public and private keys execute the following command: 
  ```bash
  ssh-keygen -t rsa -b 2048
  ```
  * It will ask for a file where to save the public key.  
   Press enter for the default path: `$HOME/.ssh/id_rsa.pub`
  * **Do not enter a passphrase**, just press enter it is better because otherwise each time you will download the repository this passphrase will be asked to you several times. 

* The public key needs now to be copied to `GitLab`. 
  * To display the public key execute:
    ```bash
    cat $HOME/.ssh/id_rsa.pub
    ```
  * Copy the whole line and then go to `GitLab` 
in the `SSH Keys` section using the link below
https://gitlab.cern.ch/-/profile/keys

  * The title of the key is not important.   

You should be now able to download any `GitLab` repository anytime on the server or your computer.
