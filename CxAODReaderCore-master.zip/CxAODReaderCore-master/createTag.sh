#!/bin/bash
#
# This script has commands for:
# 0) creating branch with the updated tags
# and tagging 1) submodules and 2) this module
###########################################################
#
# Always make sure that the submodule hash tags are the latest available
# use git status to make sure of that
# + always run first with createTags="false"
# and update the project version in the CMakeLists.txt once you get the next tag to create
# then set createTags flag to true
# NB: this script (createTag.sh) won't be commited so that the flag createTags always remains to false by default
#
# Branch and Tags will only be created if createTags is set to true
###########################################################
createTags="false" 
# choose the tag version you want to update
tagVersion="r34"

#-----------
# will contain the list of tags corresponding to the tag version
ArrayTags=()
# list all submodule version tags (of the CxAODReaderCore package) that begin by the tag version 
# add that list to ArrayTags
ArrayTags+=($(git submodule foreach git tag -l | grep "^${tagVersion}"))
# add the CxAODReaderCore tags starting by ${tagVersion}
ArrayTags+=($(git tag -l | grep "^${tagVersion}"))

# sort the Array from the highest tag to the lowest one 
SortedArrayTags=($(for l in ${ArrayTags[@]}; do echo $l; done | sort -r))
# print all ordered tags
# for value in ${SortedArrayTags[@]}; 
#   do echo $value; 
# done
latestTag=${SortedArrayTags[0]}
# replace only the first occurence
# example if latestTag="r34-20" then subTagVersion="20" and nextTag="r34-21"
subTagVersion=$(echo ${latestTag} | sed "0,/${tagVersion}-/{s/${tagVersion}-//}")
nextTag="${tagVersion}-$((subTagVersion + 1))"
# ----------

# for text printed in color
CYAN='\033[1;36m'
NC='\033[0m'

echo "Latest tag available --> ${latestTag}"
echo "Next tag to create   --> ${nextTag}"
echo -e "${CYAN}Do not forget to update version in CMakeLists.txt${NC}"

if [[ ${createTags} == "true" ]] 
then 
  function createTagModule()
  {
    tagModule=$1
    git tag -m "Tag of core Reader packages" ${tagModule}
    git push origin ${tagModule}
  }

  # 0) push hash to new branch to be merged at the end
  # timeStamp = Day_Month_Year 
  timeStamp=$(date "+%d_%m_%Y")
  branchName=master_${USER}_updateTag_${timeStamp}

  echo -e "\nCreation of Core branch = ${branchName}"
  git checkout -b ${branchName}
  git status
  git add .
  # do not add the createTag.sh script so that the flag createTags is always set to false 
  git reset createTag.sh
  git commit -m "hashtag update ${timeStamp}"
  git push --set-upstream origin ${branchName}

  # 1) Tag submodules
  echo -e "\nCreation of submodule tag = ${nextTag}"
  git submodule foreach "$(declare -f createTagModule); createTagModule ${nextTag}"
  
  # 2) Tag this module
  echo -e "\nCreation of core Reader tag = ${nextTag}"
  createTagModule ${nextTag}

  echo -e "\n${CYAN}Differences between the two tags can be found with the url below${NC}"
  echo -e "https://gitlab.cern.ch/CxAODFramework/CxAODReaderCore/-/compare/${latestTag}...${nextTag}"

  echo -e "\n${CYAN}Please do not forget to merge branch = ${branchName}${NC}"
fi

# old commands 
# do not remove them it can be useful
# step 1)
# git submodule foreach 'git tag -m "Tag of core Reader packages" r34-09'
# git submodule foreach git push origin r34-09
# step 2)
# git tag -m "Tag of core Reader packages" r34-09
# git push origin r34-09 
